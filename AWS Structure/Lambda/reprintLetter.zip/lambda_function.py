'''
    Imports
'''
import json
import boto3

aws_access_key_id='ASIAYJCKGV2TRWR6VKN5'
aws_secret_access_key='WPU2T2KSOaZMDcC4YG2XiQoo3fMQLDY77rwqHFON'
aws_session_token='FwoGZXIvYXdzEA8aDGTI+IjdZVeltCF61iK+ATzaqrTefzODHDpfqrs7P+cUakcAPyNFNwfXV1rCq4/kxqf/j3zYK67E5Pq2Kp+hriqNNmxUqY89EsQXImJk5jy5hKDLjLNaxN/ISh7fnTj5vleaBN6UpHDzd3cw6UJdarXjgAlOWAWn6/mNWKHvE59Q0VGxx0VI8tRwLjXRbo9HlxXQZGBrVuQQGstmbsQbCI65fivXef7sXE27rV9i9h9D/BAN4RdGxcJZKT4rqGza8zmncKfyr595QHEbeUAo66L8hgYyLRfY6BTa1gZB6eZBiMmsW0dCUWBUBx6x3d4OhdfxLe8W1JI0yZRMT5tEof7sZA=='
region_name='us-east-1'

'''
    Functions
'''
# Initial function, access point
def lambda_handler(event, context):
    
    return_payload = ''
    
    if event['httpMethod'] == 'GET':
        return_payload = 'This API regenerates the PDF for the l passed in the query string \'print_id\' via the POST method ONLY.'
    elif event['httpMethod'] == 'POST':
        return_payload = postMethod(event)
    else:
        return_payload = 'No method exists for ' + event['httpMethod']
    
    return {
        'statusCode': 200,
        'headers': {},
        'body': return_payload
    }

# Connect to DynamoDB
def getDynamoDB(table_name):

    dynamodb = boto3.resource('dynamodb',aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key, aws_session_token=aws_session_token, region_name=region_name)
    table = dynamodb.Table(table_name)
    return table

# Connect to DynamoDB
def getLambda():

    lambda_client = boto3.client('lambda',aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key, aws_session_token=aws_session_token, region_name=region_name)
    return lambda_client

# Create a loan
def postMethod(event):
    try:
        lambda_client = getLambda()
        
        payload = {
            'queryStringParameters':{
                'print_id': event['queryStringParameters']['print_id'],
            },
            'body': {
                'aws_access_key_id': aws_access_key_id,
                'aws_secret_access_key': aws_secret_access_key,
                'aws_session_token': aws_session_token,
                'region_name': region_name,
                'reprint': True,
            }
        }
        
        result = lambda_client.invoke(
            FunctionName='letterGenFunction',
            InvocationType='RequestResponse',
            Payload=json.dumps(payload)
        )
        range = result['Payload'].read()
        api_response = json.loads(range)
        
        return 'Letter ' + event['queryStringParameters']['print_id'] + ' has been reprinted.'
    except Exception as e:
        return 'Unable to reprint letter ' + event['queryStringParameters']['print_id'] + '. Error message: ' + str(e)
