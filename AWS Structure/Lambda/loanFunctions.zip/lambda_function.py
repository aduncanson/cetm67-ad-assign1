'''
    Imports
'''
import json
import boto3
from boto3.dynamodb.conditions import Key
from jsonschema import validate

'''
    Functions
'''

aws_access_key_id='ASIAYJCKGV2TRWR6VKN5'
aws_secret_access_key='WPU2T2KSOaZMDcC4YG2XiQoo3fMQLDY77rwqHFON'
aws_session_token='FwoGZXIvYXdzEA8aDGTI+IjdZVeltCF61iK+ATzaqrTefzODHDpfqrs7P+cUakcAPyNFNwfXV1rCq4/kxqf/j3zYK67E5Pq2Kp+hriqNNmxUqY89EsQXImJk5jy5hKDLjLNaxN/ISh7fnTj5vleaBN6UpHDzd3cw6UJdarXjgAlOWAWn6/mNWKHvE59Q0VGxx0VI8tRwLjXRbo9HlxXQZGBrVuQQGstmbsQbCI65fivXef7sXE27rV9i9h9D/BAN4RdGxcJZKT4rqGza8zmncKfyr595QHEbeUAo66L8hgYyLRfY6BTa1gZB6eZBiMmsW0dCUWBUBx6x3d4OhdfxLe8W1JI0yZRMT5tEof7sZA=='
region_name='us-east-1'

# Initial function, access point
def lambda_handler(event, context):
    
    if event.get('aws_access_key_id') is not None:
        aws_access_key_id=event['aws_access_key_id']
        aws_secret_access_key=event['aws_secret_access_key']
        aws_session_token=event['aws_session_token']
        region_name=event['region_name']
    
    return_payload = ''
    
    if event['httpMethod'] == 'GET':
        if len(event['queryStringParameters']) == 0:
            return_payload = 'Add the query parameter \'loan_id\' to the current URL to return information about the given load_id.'
        else:
            return_payload = getMethod(event)
    elif event['httpMethod'] == 'POST':
        return_payload = postMethod(event)
    else:
        return_payload = 'No method exists for ' + event['httpMethod']
    
    return {
        'statusCode': 200,
        'headers': {},
        'body': json.dumps(return_payload)
    }

# Connect to DynamoDB
def getDynamoDB(table_name):

    dynamodb = boto3.resource('dynamodb',aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key, aws_session_token=aws_session_token, region_name=region_name)
    table = dynamodb.Table(table_name)
    return table

# Get sequence number
def getSeqNum(record):
    seq_table = getDynamoDB('Sequences')
    
    current_sequence = seq_table.get_item(Key={'table_name': record})['Item']['seq']
    
    new_sequence = str(int(current_sequence) + 1)
    
    seq_table.update_item(
        Key={
            'table_name': record
        },
        UpdateExpression="set seq = :r",
        ExpressionAttributeValues={
            ':r': new_sequence,
        },
        ReturnValues="UPDATED_NEW"
    )
    
    return current_sequence

# Get count of active or pending loans for this customer
def getActiveLoan(event, loan_table):
    scan_kwargs = {
        'FilterExpression': Key('customer_id').eq(event['queryStringParameters']['customer_id']) & (Key('loan_status').eq('Pending customer confirmation') | Key('loan_status').eq('Active'))
    }
    
    table_scan = loan_table.scan(**scan_kwargs)['Items']
    
    return table_scan

# Get a loan
def getMethod(event):
    try:
        table = getDynamoDB('Loans')
        
        loan = table.get_item(Key={'loan_id': event['queryStringParameters']['loan_id']})['Item']
        
        return loan
    except Exception as e:
        return 'Unable to find loan ' + event['queryStringParameters']['loan_id'] + '. Error message: ' + str(e)

# Create a loan
def postMethod(event):
    try:
        loan_table = getDynamoDB('Loans')
        
        activeLoan = getActiveLoan(event, loan_table)
        
        if len(activeLoan) != 0:
            return 'This customer already has a loan at status \'' + activeLoan[0]['loan_status'] + '\'. Loan ID is ' + activeLoan[0]['loan_id']
        
        schema = {
            'type' : 'object',
            'properties' : {
                'loan_id' : {'type' : 'string'},
                'customer_id' : {'type' : 'string'},
                'loan_status' : {'type' : 'string'},
                'amount' : {'type' : 'string'},
                'product' : {'type' : 'string'},
                'brand' : {'type' : 'string'},
                'fees' : {'type' : 'string'},
                'start_date' : {'type' : 'string', 'pattern':'[0-9]{2}\/[0-9]{2}\/[0-9]{4}'},
                'end_date' : {'type' : 'string', 'pattern':'[0-9]{2}\/[0-9]{2}\/[0-9]{4}'},
                'letters' : {'type' : 'array'},
            },
            'required': ['loan_id', 'customer_id', 'loan_status', 'amount', 'brand', 'start_date', 'end_date', 'letters']
        }
        
        if isinstance(event['body'], str):
            body = eval(event['body'])
        else:
            body = event['body']
        
        body['loan_id'] = getSeqNum('Loans')
        body['loan_status'] = 'Pending customer confirmation'
        body['customer_id'] = event['queryStringParameters']['customer_id']
        body['product'] = 'DXC '
        
        validate(body, schema)
        
        loan_table.put_item(Item = body)
        
        customer_table = getDynamoDB('Customers')
        
        customer_table.update_item(
            Key={
                'customer_id': event['queryStringParameters']['customer_id']
            },
            UpdateExpression="SET loans = list_append(loans, :i)",
            ExpressionAttributeValues={
                ':i': [body['loan_id']],
            },
            ReturnValues="UPDATED_NEW"
        )
        
        return 'Loan created in pending status. Loan ID is ' + body['loan_id']
    except Exception as e:
        return 'Unable to create loan. Error message: ' + str(e)
