# Public packages
from reportlab.platypus import Paragraph, NextPageTemplate, PageBreak, PageTemplate, FrameBreak, Spacer
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet
from functools import partial

# My packages
from Frame import FrameFormats
from GenericFunctions import *

styles = getSampleStyleSheet()
styleN = styles['Normal']
styleN.fontSize = 11

def index(document, Story, root):
    # Create frame templates
    single = FrameFormats.single(document)
    centre_gap = 2*cm
    twoColsLeft = FrameFormats.twoColsLeft(document, centre_gap)
    twoColsRight = FrameFormats.twoColsRight(document, centre_gap)
    envelopeWindow = FrameFormats.envelopeWindow(document)
    envelopeWindowSerial = FrameFormats.envelopeWindowSerial(document)
    poBoxWindow = FrameFormats.poBoxWindow(document)
    underEnvWindow = FrameFormats.underEnvWindow(document)

    # Create the page templates
    coverPage = PageTemplate(id='Cover', frames=[envelopeWindow, envelopeWindowSerial, poBoxWindow, underEnvWindow], onPage=OnPage.logo, onPageEnd=partial(OnPage.footer, footer=root['brand']['footer']))
    singleFramedPage = PageTemplate(id='OneCol', frames=single, onPageEnd=partial(OnPage.footer, footer=root['brand']['footer']))
    twoFramedPage = PageTemplate(id='TwoCol', frames=[twoColsLeft, twoColsRight], onPage=partial(OnPage.footer, footer=root['brand']['footer']))

    # Add page templates to document template
    document.addPageTemplates([
        coverPage,
        singleFramedPage,
        twoFramedPage,
    ])

    Story.append(Paragraph('<br /><b>Your ' + root['brand']['bank'] + ' ' + root['product'] + ' Loan account number ' + root['lan'] + '</b>', styleN))
    Story.append(Paragraph('<br />Thank you for completing your loan with ' + root['brand']['bank'] + '.', styleN))
    Story.append(Paragraph('<br />You have fully repaid the balance £' + root['amount'] + '.', styleN))
    if root.get('fees') is None:
        Story.append(Paragraph('<br />You had no fees to repay.', styleN))
    else:
        Story.append(Paragraph('<br />You have fully repaid the outstanding fees totalling £' + root['fees'] + '.', styleN))
    Story.append(Paragraph('<br />Yours sincerely<br /><br />Personal Loans Service Centre<br />' + root['brand']['contact_number'] + '<br />Opening Hours: ' + root['brand']['opening_times'] + '<br /><br /><b>If you\'d like this in Braille, large print or audio, please ask us.</ b>', styleN))
