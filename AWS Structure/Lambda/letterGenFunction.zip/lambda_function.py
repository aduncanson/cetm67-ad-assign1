'''
    Imports
'''
import json
import boto3
from Document import DocFormats
from LetterLibrary import *
from GenericFunctions import *
from Frame import LetterStart
from jsonschema import validate
'''
    Functions
'''

# Connect to DynamoDB
def getDynamoDB(table_name, aws_access_key_id, aws_secret_access_key, aws_session_token, region_name):

    dynamodb = boto3.resource('dynamodb',aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key, aws_session_token=aws_session_token, region_name=region_name)
    table = dynamodb.Table(table_name)
    return table

# Get a loan
def getLoan(loan_id, aws_access_key_id, aws_secret_access_key, aws_session_token, region_name):
    table = getDynamoDB('Loans', aws_access_key_id, aws_secret_access_key, aws_session_token, region_name)
    
    loan = table.get_item(Key={'loan_id': loan_id})['Item']
    
    return loan

# Get a customer
def getCustomer(customer_id, aws_access_key_id, aws_secret_access_key, aws_session_token, region_name):
    table = getDynamoDB('Customers', aws_access_key_id, aws_secret_access_key, aws_session_token, region_name)
    
    customer = table.get_item(Key={'customer_id': customer_id})['Item']
    
    return customer

# Get a schema
def getSchema(letter_code, aws_access_key_id, aws_secret_access_key, aws_session_token, region_name):
    table = getDynamoDB('LetterLibrary', aws_access_key_id, aws_secret_access_key, aws_session_token, region_name)
    
    schema = table.get_item(Key={'letter_code': letter_code})['Item']['schema']
    
    return schema

# Get reprint root data
def getReprint(print_id, aws_access_key_id, aws_secret_access_key, aws_session_token, region_name):
    table = getDynamoDB('PrintArchive', aws_access_key_id, aws_secret_access_key, aws_session_token, region_name)
    
    root_data = table.get_item(Key={'print_id': print_id})['Item']['root_data']
    
    return root_data

# Get sequence number
def getSeqNum(record, aws_access_key_id, aws_secret_access_key, aws_session_token, region_name):
    seq_table = getDynamoDB('Sequences', aws_access_key_id, aws_secret_access_key, aws_session_token, region_name)
    
    current_sequence = seq_table.get_item(Key={'table_name': record})['Item']['seq']
    
    new_sequence = str(int(current_sequence) + 1)
    
    seq_table.update_item(
        Key={
            'table_name': record
        },
        UpdateExpression="set seq = :r",
        ExpressionAttributeValues={
            ':r': new_sequence,
        },
        ReturnValues="UPDATED_NEW"
    )
    
    return current_sequence

# Initial function, access point
def lambda_handler(event, context):
    
    try:
        
        if type(event) == "str":
            body = eval(event['body'])
        else:
            body = event['body']
        
        # Config
        aws_access_key_id=body["aws_access_key_id"]
        aws_secret_access_key=body["aws_secret_access_key"]
        aws_session_token=body["aws_session_token"]
        region_name=body["region_name"]
        s3 = boto3.client('s3',aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key, aws_session_token=aws_session_token, region_name=region_name)
        
        if body.get("reprint") is None:
            # Data always needed
            loan_id = event['queryStringParameters']['loan_id']
            letter_template = event['queryStringParameters']['letter_type']
            loan = getLoan(loan_id, aws_access_key_id, aws_secret_access_key, aws_session_token, region_name)
            customer = getCustomer(loan['customer_id'], aws_access_key_id, aws_secret_access_key, aws_session_token, region_name)
            print_id = getSeqNum('Letter', aws_access_key_id, aws_secret_access_key, aws_session_token, region_name)
            brand_info = BrandInfo.index(loan['brand'])
            schema = getSchema(letter_template, aws_access_key_id, aws_secret_access_key, aws_session_token, region_name)
            
            # Get root data for document
            root = eval('RootBuilder.' + letter_template + '(loan, customer, print_id, brand_info)')
            
            validate(root, schema)
        else:
            root = getReprint(event['queryStringParameters']['print_id'], aws_access_key_id, aws_secret_access_key, aws_session_token, region_name)
        
        s3.download_file('print-document-images', root['brand']['bank'] + '_Bank_Logo.png', '/tmp/logo.png')
    
        # My letter variables
        Story = []
        document = DocFormats.docTemplate("/tmp/print_id_" + root['print_id'])
    
        # Generic to all letters at start
        LetterStart.index(Story, root)
    
        # Get letter library
        eval(root['letter'] + '.index(document, Story, root)')
    
        # Build the PDF
        document.build(Story)
        
        s3.upload_file('/tmp/print_id_' + root['print_id'] + '.pdf', 'printed-documents', 'print_id_' + root['print_id'] + '.pdf')
        
        if body.get("reprint") is None:
            loan_table = getDynamoDB('Loans', aws_access_key_id, aws_secret_access_key, aws_session_token, region_name)
            
            loan_table.update_item(
                Key={
                    'loan_id': loan_id
                },
                UpdateExpression="SET letters = list_append(letters, :i)",
                ExpressionAttributeValues={
                    ':i': [root['print_id']],
                },
                ReturnValues="UPDATED_NEW"
            )
            
            print_archive = getDynamoDB('PrintArchive', aws_access_key_id, aws_secret_access_key, aws_session_token, region_name)
            
            print_item = {
                'print_id': root['print_id'],
                'root_data': root
            }
            
            print_archive.put_item(Item = print_item)
        
        return 'Create document \'' + root['letter'] + '\' for loan ' + loan_id
    except Exception as e:
        return 'Unable to create \'' + event['queryStringParameters']['letter_type'] + '\' document for loan ' + event['queryStringParameters']['loan_id'] + '. Error message: ' + str(e)
