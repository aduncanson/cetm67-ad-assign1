from reportlab.platypus import Paragraph
from reportlab.lib.units import cm

def blankAfter(canvas,document):
    canvas.showPage()

def footer(canvas,document,footer):
    canvas.saveState()
    textobject = canvas.beginText()
    textobject.setTextOrigin(document.leftMargin, document.bottomMargin+0.5*cm)
    textobject.setFont('Times-Roman', 6)
    textobject.textLines(footer)
    canvas.drawText(textobject)
    canvas.setFont('Times-Roman',9)
    canvas.drawString(cm, 0.75 * cm, 'Page %d' % document.page)
    canvas.restoreState()
    blankAfter(canvas,document)

def logo(canvas,document):
    ratioSize = 2*cm
    canvas.drawImage('/tmp/logo.png', document.leftMargin, document.height-ratioSize+document.bottomMargin, ratioSize*10, ratioSize, mask='auto', preserveAspectRatio=True, showBoundary=False, anchor='nw')