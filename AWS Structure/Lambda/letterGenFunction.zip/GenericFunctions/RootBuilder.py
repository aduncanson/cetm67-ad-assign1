from datetime import datetime

def Welcome(loan, customer, print_id, brand_info):
    root = {
        "letter": "Welcome",
        "print_id": print_id,
        "created_when": datetime.now().strftime('%d %B %Y'),
        "product": loan['product'],
        "lan": loan['loan_id'],
        "amount": loan['amount'],
        "start_date": datetime.strptime(loan['start_date'], '%d/%m/%Y').strftime('%d&nbsp;%B&nbsp;%Y'),
        "end_date": datetime.strptime(loan['end_date'], '%d/%m/%Y').strftime('%d&nbsp;%B&nbsp;%Y'),
        "address": customer['address'],
        "client": customer['name'],
        "brand": brand_info,
    }
    return root

def Closed(loan, customer, print_id, brand_info):
    root = {
        "letter": "Closed",
        "print_id": print_id,
        "created_when": datetime.now().strftime('%d %B %Y'),
        "product": loan['product'],
        "lan": loan['loan_id'],
        "amount": loan['amount'],
        "start_date": datetime.strptime(loan['start_date'], '%d/%m/%Y').strftime('%d&nbsp;%B&nbsp;%Y'),
        "end_date": datetime.strptime(loan['end_date'], '%d/%m/%Y').strftime('%d&nbsp;%B&nbsp;%Y'),
        "address": customer['address'],
        "client": customer['name'],
        "brand": brand_info,
    }
    if loan.get('fees') is not None:
        root['fees'] = loan['fees']
    return root
