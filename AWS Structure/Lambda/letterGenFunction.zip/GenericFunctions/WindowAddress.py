def index(address):
    address_str = []
    address_str.append(address['line1'])
    if address.get('line2') is not None:
        address_str.append(address['line2'])
    if address.get('line3') is not None:
        address_str.append(address['line3'])
    address_str.append(address['county'])
    address_str.append(address['postcode'])
    return '<br></br>'.join(address_str)