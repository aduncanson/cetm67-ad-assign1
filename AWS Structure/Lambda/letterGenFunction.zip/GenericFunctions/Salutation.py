def DearCustomer(client):
    name_str = []
    name_str.append(client['title'])
    name_str.append(client['first_name'])
    if client.get('middle_names') is not None:
        middle_names = client.get('middle_names').split()
        for m_name in middle_names:
            name_str.append(m_name[0])
    name_str.append(client['surname'])
    return ' '.join(name_str)

def WindowName(client):
    name_str = []
    name_str.append(client['title'])
    name_str.append(client['first_name'][0])
    name_str.append(client['surname'])
    return ' '.join(name_str)