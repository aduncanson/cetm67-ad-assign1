def index(brand):
    if brand == 'Lloyds':
        data = {
            "bank": "Lloyds",
            "contact_number": '0330 123 3890',
            "url": 'www.lloydsbank.com',
            'footer': '''Lloyds Bank plc Registered Office, 25 Gresham Street, London EC2V 7HN. Registered in England and Wales number 2065
            Authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority
            and the Prudential Regulation Authority under registration number 119278. We adhere to The Standards of Lending Practice
            which are monitored and enforced by the LSB: https://www.lendingstandardsboard.org.uk
            We are members of the Financial Services compensation scheme and the Financial Ombudsman Service''',
            'opening_times': 'seven days a week, 8am to 10pm.',
        }
        return data
    elif brand == 'Halifax':
        data = {
            "bank": "Halifax",
            "contact_number": '0345 604 7292',
            "url": 'www.halifax.co.uk',
            'footer': '''Halifax is a division of Bank of Scotland plc. Registered in Scotland No. SC327000. Registered Office: The Mound, Edinburgh EH1 1YZ.
            Bank of Scotland plc is authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority under registration number 169628.''',
            'opening_times': 'seven days a week, 8am to 10pm.',
        }
        return data
    elif brand == 'BOS':
        data = {
            "bank": "Bank of Scotland",
            "contact_number": '0345 604 7291',
            "url": 'www.bankofscotland.co.uk',
            'footer': '''Bank of Scotland plc, registered in Scotland No. SC327000.
            Registered Office: The Mound, Edinburgh EH1 1YZ.
            Bank of Scotland plc is authorised by the
            Prudential Regulation Authority and
            regulated by the Financial Conduct
            Authority and the Prudential Regulation
            Authority under registration number 169628.''',
            'opening_times': 'seven days a week, 8am to 10pm.',
        }
        return data
    elif brand == 'MBNA':
        data = {
            "bank": "MBNA",
            "contact_number": '0330 678 1430',
            "url": 'www.mbna.co.uk/loans',
            'footer': '''MBNA is a trading style of Lloyds Bank plc. Lloyds Bank plc Registered Office, 25 Gresham Street, London EC2V 7HN.
            Registered in England and Wales number 2065 Authorised by the Prudential Regulation Authority and regulated by
            the Financial Conduct Authority and the Prudential Regulation Authority under registration number 119278.
            We adhere to the Standards of Lending Practice, which are monitored and enforced by the LSB (lendingstandardsboard.org.uk/)''',
            'opening_times': 'seven days a week, 8am to 10pm.',
        }
        return data
    else:
        return None
