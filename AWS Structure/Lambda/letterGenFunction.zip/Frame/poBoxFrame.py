from reportlab.platypus import Paragraph
from reportlab.lib.styles import getSampleStyleSheet
styles = getSampleStyleSheet()

def index(Story, root):
    Story.append(Paragraph('PO Box 43', styles['Normal']))
    Story.append(Paragraph('Peterlee', styles['Normal']))
    Story.append(Paragraph('County Durham', styles['Normal']))
    Story.append(Paragraph('SR8 2YQ', styles['Normal']))
    Story.append(Paragraph('<br />Need help? Please call us on ' + root['brand']['contact_number'], styles['Normal']))
    Story.append(Paragraph('<br />' + root['brand']['url'], styles['Normal']))
    Story.append(Paragraph('<br />' + root['created_when'], styles['Normal']))
