from reportlab.platypus import Frame
from reportlab.lib.units import cm

# Generic page frames
def single(document):
    return Frame(document.leftMargin, document.bottomMargin, document.width, document.height, id = 'normal')

def twoColsLeft(document, centre_gap):
    return Frame(document.leftMargin, document.bottomMargin, (document.width-centre_gap)/2, document.height, id='col1')

def twoColsRight(document, centre_gap):
    return Frame(document.leftMargin+(document.width+centre_gap)/2, document.bottomMargin, (document.width-centre_gap)/2, document.height, id='col2')

# Cover page frames
def envelopeWindow(document):
    frameWidth = 7*cm
    frameHeight = 4*cm
    return Frame(document.leftMargin, document.height+document.bottomMargin-frameHeight-3*cm, frameWidth, frameHeight, id='envWindow')

def envelopeWindowSerial(document):
    frameWidth = 7*cm
    frameHeight = 4*cm
    return Frame(document.leftMargin, document.height+document.bottomMargin-frameHeight-3*cm, frameWidth, frameHeight, id='envWindow2')

def poBoxWindow(document):
    frameWidth = 8*cm
    frameHeight = 6.5*cm
    return Frame(document.leftMargin+document.width-frameWidth, document.height+document.bottomMargin-frameHeight-0.5*cm, frameWidth, frameHeight, id='poBoxWindow')

def underEnvWindow(document):
    return Frame(document.leftMargin, document.bottomMargin+1*cm, document.width, 17.5*cm, id='underEnvWindow')
