from reportlab.platypus import Paragraph, FrameBreak, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import cm

from Frame import poBoxFrame
from GenericFunctions import Salutation, WindowAddress

styles = getSampleStyleSheet()
rightAlign = getSampleStyleSheet()
rightAlign['Normal'].alignment = 2

def index(Story, root):
    Story.append(Paragraph(Salutation.WindowName(root['client']), styles['Normal']))
    Story.append(Paragraph(WindowAddress.index(root['address']), styles['Normal']))
    Story.append(FrameBreak())
    Story.append(Spacer(1, 3*cm))
    Story.append(Paragraph(root['letter'] + '_' + root['print_id'], rightAlign['Normal']))
    Story.append(FrameBreak())
    poBoxFrame.index(Story, root)
    Story.append(FrameBreak())
    Story.append(Paragraph(Salutation.DearCustomer(root['client']), styles['Normal']))
