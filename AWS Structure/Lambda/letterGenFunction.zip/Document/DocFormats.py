from reportlab.platypus import BaseDocTemplate
from reportlab.lib import pagesizes
from reportlab.lib.units import cm

# Create the default document template
def docTemplate(name):
    return BaseDocTemplate(name + '.pdf', showBoundary=0, pagesize=pagesizes.A4, leftMargin=1.5*cm, rightMargin=1.5*cm, topMargin=1.5*cm, bottomMargin=1.5*cm)
