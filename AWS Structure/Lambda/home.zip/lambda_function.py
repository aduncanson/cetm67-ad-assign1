import json

def lambda_handler(event, context):
    
    return_payload = ''
    
    if event['httpMethod'] == 'GET':
        return_payload = '''This is the root of Adam Duncanson\'s CETM67 Assignment 1 API AWS pages
    There are several extensions to this home page:
        / (GET) - Home page
        /customer (GET,POST) - Gathers customer details and creates new customers
        /downloadPDF (GET) - Downloads PDF for print_id passed in
        /empty-s3-bucket (GET,POST) - Empties the passed s3 bucket
        /loan (GET,POST) - Gathers loan details and creates new loans
        /loan/activate (GET,POST) - Activates or cancels a pending loan
        /loan/close (GET,POST) - Closes an active loan
        /reprint-letter (GET,POST) - regenerates previously created PDFs by their archived meta-data'''
    else:
        return_payload = 'No method exists for ' + event['httpMethod']
    
    return {
        'statusCode': 200,
        'headers': {},
        'body': return_payload
    }
