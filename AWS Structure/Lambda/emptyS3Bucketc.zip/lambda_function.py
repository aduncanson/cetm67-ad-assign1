import json
import boto3

aws_access_key_id='ASIAYJCKGV2TRWR6VKN5'
aws_secret_access_key='WPU2T2KSOaZMDcC4YG2XiQoo3fMQLDY77rwqHFON'
aws_session_token='FwoGZXIvYXdzEA8aDGTI+IjdZVeltCF61iK+ATzaqrTefzODHDpfqrs7P+cUakcAPyNFNwfXV1rCq4/kxqf/j3zYK67E5Pq2Kp+hriqNNmxUqY89EsQXImJk5jy5hKDLjLNaxN/ISh7fnTj5vleaBN6UpHDzd3cw6UJdarXjgAlOWAWn6/mNWKHvE59Q0VGxx0VI8tRwLjXRbo9HlxXQZGBrVuQQGstmbsQbCI65fivXef7sXE27rV9i9h9D/BAN4RdGxcJZKT4rqGza8zmncKfyr595QHEbeUAo66L8hgYyLRfY6BTa1gZB6eZBiMmsW0dCUWBUBx6x3d4OhdfxLe8W1JI0yZRMT5tEof7sZA=='
region_name='us-east-1'

def lambda_handler(event, context):
    
    return_payload = ''
    
    if event['httpMethod'] == 'GET':
        return_payload = 'This API empties the given bucket passed in the query string \'bucket_name\' via the POST method ONLY.'
    elif event['httpMethod'] == 'POST':
        return_payload = postMethod(event)
    else:
        return_payload = 'No method exists for ' + event['httpMethod']
    
    return {
        'statusCode': 200,
        'headers': {},
        'body': return_payload
    }

def postMethod(event):
    
    try:

        s3 = boto3.resource('s3',aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key, aws_session_token=aws_session_token, region_name=region_name)
        
        bucket = s3.Bucket(event['queryStringParameters']['bucket_name'])
        bucket.objects.all().delete()
    
        return 'All objects deleted from bucket \'' + event['queryStringParameters']['bucket_name'] + '\'.'
    except Exception as e:
        return 'Unable to delete all objects from bucket \'' + event['queryStringParameters']['bucket_name'] + '\'. Error message: ' + str(e)
